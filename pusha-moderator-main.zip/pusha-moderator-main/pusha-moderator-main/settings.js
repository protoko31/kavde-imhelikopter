module.exports = {
    bot: {
        botOwner: ["619126609756160000"],
        botToken: "token",
        botPrefix: ".",
        botStatus: "VANESSA ❤️ SHELBY",
        botVoice: "",
        mongoURL: "mongo url",
    },
    

    roles: {
        muteStaff: ["882755202812370984"],
        vmuteStaff: ["882755203856744528"],
        jailStaff: ["882755200610340865"],
        banStaff: ["882755199939264562"],
        muteRole: "882755238359089204",
        vMuteRole: "882755239307018270",
        jailRole: "882755240728854558",
        unregisterRoles: ["882755214921306202"],
        tagRole: "884130807785091132",
        vipRole: "882755208596316221",
        boosterRole: "784640746983784458",
        enAltYt: "882755190703419393",
        katıldı: "882755218939449364",
        yasaklıTag: "882755241236398093"
    },

    channels: {
        genelChat: "882755316641570836",
        tagLog: "882755410912751636",
        muteLog: "882755423994793984",
        vMuteLog: "882755426012266546",
        jailLog: "882755417233563678",
        banLog: "882755415010598912",
        messageLog: "882772842448576603",
        meeting: "858107428062232636",
        rolLog: "882772868218372157",
        voiceLog: "882755413106364426",
        yasaklıtagLog: "882784707513843712",
        pubCategoryID: ["882755278137880606","882755277319974962","882755276485296168","882755269761835028",],

    },

    guild: {
        guildID: "774977651429212181",
        tagges: ["✰"], // buraya taglarınızı giriyorsunuz etiket için: #0001 olarak
        nameTag: "✰", // buraya tagı varsa ismin başına gelcek tag
        defaultTag: "✰", // burda tagı yoksa ismin başına gelcek tag
        banLimit: 5

    },

    emojis: {
        yes: "881582775617069106", // EMOJİLERİN SADECE ID GİRECEKSİNİZ 
        no: "784635066906705920",
        on: "881582775617069106",
        off: "784635066906705920"
    }

};
