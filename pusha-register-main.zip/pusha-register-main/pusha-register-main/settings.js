module.exports = {
    bot: {
        botOwner: ["619126609756160000"],//Bot Sahibi İdiniz
        botToken: "",//Botun Tokenı 
        botPrefix: ".",//Botun Prefixi
        botStatus: "VANESSA ❤️ SHELBY",//Bot Durumu Kafanıza Göre Girin
        mongoURL: "",//Mongo Url Gireceksiniz Buraya
    },
    roles: {
        vipStaff: ["882755201923178537"],//Vip Hammer İd
        registerStaff: ["882755204334899202"],//Register Hammer İd
        manRoles: ["882755212652199976","882755213428137994"], // erkek rolleri
        womanRoles: ["882755210173358090","882755210752188507"], // kız rolleri
        unregisterRoles: ["882755214921306202"],//Kayıtsız İd
        tagRole: "884130807785091132",//Tag Rol İd
        vipRole: "882755208596316221",//Vip Rol İd
        boosterRole: "784640746983784458",//Booster Rol İd
        suspecious: "883496517657321492" // şüpheli hesap rolü
    },
    channels: {
        registerChannel: "882755300111835196",//Hosgeldin Kanalı İd
        rulesChannel: "882755307305066506",//Kurallar Kanalı İd
        botVoice: "",// Botun Sese Girecek Kanal İd

    },
    guild: {
        guildID: "774977651429212181",//Sunuucu İd
        tag: "✬", // BURAYA İSMİN BAŞINA GELECEK TAG BİRDEN ÇOK TAGINIZ VARSA AŞŞAĞIYA GİRİN
        tagges: [], // BİRDEN ÇOK TAGINIZ VARSA BURAYA GİRİN ÖRNEK: #0001
        defaultTag: "•",
        defaultName: "• İsim Yaş",
        suspeciousName: "• Şüpheli Hesap",
    },
    emojis: {
        yes: "881582775617069106",
        no: "784635066906705920",
        // EMOJİLERİN ID GİRCEKSİNİZ SADECE ID
    }

};
