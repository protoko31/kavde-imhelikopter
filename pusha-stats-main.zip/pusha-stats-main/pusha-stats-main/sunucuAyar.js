const ayarlar = {
  guildID: '', // sunucu idsi
  ownerRole:"", // sunucu sahiplerinin rolü
  teyitsizRolleri:[""], // kayıt olmayanlara verieln rol
  jailRolu:["","",], // cezalılara verilen rol
  enAltYetkiliRolu:[""], // ilk yetkili permi
  activity:" ❤️ PUSHA", // botun durumu
  status:"idle",
  invitelink:"https://discord.gg/theaspendos", //davet linki
  symbol:"✰", // tag
  voicechannel:"" // botun gireceği ses kanalı
};
module.exports = ayarlar;