const config = { 
//------------Connections-----------//
    Client_Token: 'TOKEN',
    MongoDB_ConnectURL: 'MONGO URL',
    //------------BotSettings-----------//
    Prefix: '.',
    BotOwners: ["OWNER İD"],
    Custom_Status_Text: 'ASPENDOS ❤️ PUSHA',
    Custom_Status_Type: 'PLAYING', // => PLAYING / WATCHING / LISTENING
    Custom_Status: 'dnd', // => dnd / idle / online / invisible
   
};
  
module.exports = config;
